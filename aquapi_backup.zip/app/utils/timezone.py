# app/utils/timezone.py

from datetime import timezone, timedelta

IST = timezone(timedelta(hours=5, minutes=30))
